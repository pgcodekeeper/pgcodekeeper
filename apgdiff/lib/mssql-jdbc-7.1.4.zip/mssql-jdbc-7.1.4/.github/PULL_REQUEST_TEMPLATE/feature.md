---
name: Feature
about: Propose a new feature to the driver
title: "Feature | "

---

## Brief Description
<!--- Briefly describe the feature introduced with the PR. --->

<!--- Optional --->
### Fixes existing GitHub issue
<!--- Provide link to GitHub issue above. --->

## New Public APIs
<!--- List any new public APIs added with this Feature. --->
